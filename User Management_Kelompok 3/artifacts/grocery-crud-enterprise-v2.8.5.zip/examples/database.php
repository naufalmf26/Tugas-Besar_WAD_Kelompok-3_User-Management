<?php
return [
    'adapter' => [
        'driver' => 'Pdo_Mysql',
        'database' => 'test_database',
        'username' => '',
        'password' => '',
        'charset' => 'utf8'
    ]
];